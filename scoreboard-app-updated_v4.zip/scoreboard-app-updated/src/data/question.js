const questions = [
{
  id: "LINK",
  label: "LINK",
  questions: [
    {
    id: "L1",
    question: "What is the main purpose of an organizational structure?",
    options: [
      { text: "Define roles and responsibilities", marks: 5 },
      { text: "Increase individual workload", marks: 1 },
      { text: "Reduce communication", marks: 2 },
      { text: "Eliminate management", marks: 3 },
    ],
    correctAnswer: "Define roles and responsibilities",
  },
  {
    id: "L2",
    question: "Effective time utilization at work mainly helps to:",
    options: [
      { text: "Complete tasks on time", marks: 5 },
      { text: "Increase stress", marks: 1 },
      { text: "Avoid collaboration", marks: 2 },
      { text: "Delay decision making", marks: 3 },
    ],
    correctAnswer: "Complete tasks on time",
  },
  {
    id: "L3",
    question: "Which practice improves productivity in an organization?",
    options: [
      { text: "Task prioritization", marks: 5 },
      { text: "Micromanagement", marks: 2 },
      { text: "Unclear goals", marks: 1 },
      { text: "Ignoring deadlines", marks: 3 },
    ],
    correctAnswer: "Task prioritization",
  },
  {
    id: "L4",
    question: "What is the most effective way to utilize team skills?",
    options: [
      { text: "Assign tasks based on strengths", marks: 5 },
      { text: "Give same tasks to everyone", marks: 2 },
      { text: "Avoid delegation", marks: 1 },
      { text: "Limit collaboration", marks: 3 },
    ],
    correctAnswer: "Assign tasks based on strengths",
  },
  {
    id: "L5",
    question:
      "Which habit contributes most to effective workplace performance?",
    options: [
      { text: "Setting clear priorities", marks: 5 },
      { text: "Working without planning", marks: 1 },
      { text: "Ignoring feedback", marks: 2 },
      { text: "Multitasking excessively", marks: 3 },
    ],
    correctAnswer: "Setting clear priorities",
  },
  {
    id: "L6",
    question:
      "Which habit contributes most to effective workplace performance?",
    options: [
      { text: "Setting clear priorities", marks: 5 },
      { text: "Working without planning", marks: 1 },
      { text: "Ignoring feedback", marks: 2 },
      { text: "Multitasking excessively", marks: 3 },
    ],
    correctAnswer: "Setting clear priorities",
  },
  {
    id: "L7",
    question:
      "Which habit contributes most to effective workplace performance?",
    options: [
      { text: "Setting clear priorities", marks: 5 },
      { text: "Working without planning", marks: 1 },
      { text: "Ignoring feedback", marks: 2 },
      { text: "Multitasking excessively", marks: 3 },
    ],
    correctAnswer: "Setting clear priorities",
  },
  {
    id: "L8",
    question:
      "Which habit contributes most to effective workplace performance?",
    options: [
      { text: "Setting clear priorities", marks: 5 },
      { text: "Working without planning", marks: 1 },
      { text: "Ignoring feedback", marks: 2 },
      { text: "Multitasking excessively", marks: 3 },
    ],
    correctAnswer: "Setting clear priorities",
  }
  ]
},

{
  id: "ENGAGE",
  label: "ENGAGE",
  questions: [
    {
    id: "E1",
    question: "What is the main purpose of an organizational structure?",
    options: [
      { text: "Define roles and responsibilities", marks: 5 },
      { text: "Increase individual workload", marks: 1 },
      { text: "Reduce communication", marks: 2 },
      { text: "Eliminate management", marks: 3 },
    ],
    correctAnswer: "Define roles and responsibilities",
  },
  {
    id: "E2",
    question: "Effective time utilization at work mainly helps to:",
    options: [
      { text: "Complete tasks on time", marks: 5 },
      { text: "Increase stress", marks: 1 },
      { text: "Avoid collaboration", marks: 2 },
      { text: "Delay decision making", marks: 3 },
    ],
    correctAnswer: "Complete tasks on time",
  },
  {
    id: "E3",
    question: "Which practice improves productivity in an organization?",
    options: [
      { text: "Task prioritization", marks: 5 },
      { text: "Micromanagement", marks: 2 },
      { text: "Unclear goals", marks: 1 },
      { text: "Ignoring deadlines", marks: 3 },
    ],
    correctAnswer: "Task prioritization",
  },
  {
    id: "E4",
    question: "What is the most effective way to utilize team skills?",
    options: [
      { text: "Assign tasks based on strengths", marks: 5 },
      { text: "Give same tasks to everyone", marks: 2 },
      { text: "Avoid delegation", marks: 1 },
      { text: "Limit collaboration", marks: 3 },
    ],
    correctAnswer: "Assign tasks based on strengths",
  },
  {
    id: "E5",
    question:
      "Which habit contributes most to effective workplace performance?",
    options: [
      { text: "Setting clear priorities", marks: 5 },
      { text: "Working without planning", marks: 1 },
      { text: "Ignoring feedback", marks: 2 },
      { text: "Multitasking excessively", marks: 3 },
    ],
    correctAnswer: "Setting clear priorities",
  }
  ]
},

{
  id: "ACTIVATE",
  label: "ACTIVATE",
  questions: [
    {
    id: "A1",
    question: "What is the main purpose of an organizational structure?",
    options: [
      { text: "Define roles and responsibilities", marks: 5 },
      { text: "Increase individual workload", marks: 1 },
      { text: "Reduce communication", marks: 2 },
      { text: "Eliminate management", marks: 3 },
    ],
    correctAnswer: "Define roles and responsibilities",
  },
  {
    id: "A2",
    question: "Effective time utilization at work mainly helps to:",
    options: [
      { text: "Complete tasks on time", marks: 5 },
      { text: "Increase stress", marks: 1 },
      { text: "Avoid collaboration", marks: 2 },
      { text: "Delay decision making", marks: 3 },
    ],
    correctAnswer: "Complete tasks on time",
  },
  {
    id: "A3",
    question: "Which practice improves productivity in an organization?",
    options: [
      { text: "Task prioritization", marks: 5 },
      { text: "Micromanagement", marks: 2 },
      { text: "Unclear goals", marks: 1 },
      { text: "Ignoring deadlines", marks: 3 },
    ],
    correctAnswer: "Task prioritization",
  },
  {
    id: "A4",
    question: "What is the most effective way to utilize team skills?",
    options: [
      { text: "Assign tasks based on strengths", marks: 5 },
      { text: "Give same tasks to everyone", marks: 2 },
      { text: "Avoid delegation", marks: 1 },
      { text: "Limit collaboration", marks: 3 },
    ],
    correctAnswer: "Assign tasks based on strengths",
  }
  ]
},

{
  id: "DRIVE",
  label: "DRIVE",
  questions: [
    {
    id: "D1",
    question: "What is the main purpose of an organizational structure?",
    options: [
      { text: "Define roles and responsibilities", marks: 5 },
      { text: "Increase individual workload", marks: 1 },
      { text: "Reduce communication", marks: 2 },
      { text: "Eliminate management", marks: 3 },
    ],
    correctAnswer: "Define roles and responsibilities",
  },
  {
    id: "D2",
    question: "Effective time utilization at work mainly helps to:",
    options: [
      { text: "Complete tasks on time", marks: 5 },
      { text: "Increase stress", marks: 1 },
      { text: "Avoid collaboration", marks: 2 },
      { text: "Delay decision making", marks: 3 },
    ],
    correctAnswer: "Complete tasks on time",
  },
  {
    id: "D3",
    question: "Which practice improves productivity in an organization?",
    options: [
      { text: "Task prioritization", marks: 5 },
      { text: "Micromanagement", marks: 2 },
      { text: "Unclear goals", marks: 1 },
      { text: "Ignoring deadlines", marks: 3 },
    ],
    correctAnswer: "Task prioritization",
  }
  ]
}
];

export default questions;
