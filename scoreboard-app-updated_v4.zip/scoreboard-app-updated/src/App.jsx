import { useState } from "react";
import questionSections from "./data/question";
import ScoreDisplay from "./Components/ScoreDisplay";
import QuestionSlider from "./Components/QuestionSlider";
import StepperTop from "./Components/StepperTop";
import StepperBottom from "./Components/StepperBottom";
import CompletionPage from "./Components/CompletedScorePage";

function App() {
  const [score, setScore] = useState(0);
  const [answered, setAnswered] = useState({});
  const [currentSectionIndex, setCurrentSectionIndex] = useState(0);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [isCompleted, setIsCompleted] = useState(false);

  // ✅ FIX: ADD sectionScores STATE
  const [sectionScores, setSectionScores] = useState(() =>
    questionSections.reduce((acc, section) => {
      acc[section.key] = 0; // LINK, ENGAGE, ACTIVATE, DRIVE
      return acc;
    }, {}),
  );

  const currentSection = questionSections[currentSectionIndex];
  const currentQuestions = currentSection.questions;

  const maxScore = questionSections
    .flatMap((s) => s.questions)
    .reduce((sum, q) => sum + Math.max(...q.options.map((o) => o.marks)), 0);

  // ✅ FIX: UPDATE sectionScores SAFELY
  const handleAnswer = (question, option) => {
    if (answered[question.id]) return;

    setScore((prev) => prev + option.marks);

    setSectionScores((prev) => ({
      ...prev,
      [currentSection.key]: prev[currentSection.key] + option.marks,
    }));

    setAnswered((prev) => ({
      ...prev,
      [question.id]: option.text,
    }));
  };

  const goNext = () => {
    if (currentQuestionIndex < currentQuestions.length - 1) {
      setCurrentQuestionIndex((prev) => prev + 1);
    } else if (currentSectionIndex < questionSections.length - 1) {
      setCurrentSectionIndex((prev) => prev + 1);
      setCurrentQuestionIndex(0);
    } else {
      // ✅ ALL SECTIONS & QUESTIONS DONE
      setIsCompleted(true);
    }
  };

  const goPrev = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex((prev) => prev - 1);
    } else if (currentSectionIndex > 0) {
      const prevSection = questionSections[currentSectionIndex - 1];
      setCurrentSectionIndex((prev) => prev - 1);
      setCurrentQuestionIndex(prevSection.questions.length - 1);
    }
  };

  return (
    <div className="container-fluid p-4">
      {isCompleted ? (
        <CompletionPage />
      ) : (
        <>
          <ScoreDisplay
            totalScore={score}
            totalMaxScore={maxScore}
            sectionScores={sectionScores}
            questionSections={questionSections}
            activeSectionIndex={currentSectionIndex}
          />

          <StepperTop activeStep={currentSectionIndex} />

          <QuestionSlider
            question={currentQuestions[currentQuestionIndex]}
            onAnswer={handleAnswer}
            answered={answered}
            goNext={goNext}
            goPrev={goPrev}
          />

          <StepperBottom
            totalSteps={currentQuestions.length}
            activeStep={currentQuestionIndex}
          />
        </>
      )}
    </div>
  );
}

export default App;
