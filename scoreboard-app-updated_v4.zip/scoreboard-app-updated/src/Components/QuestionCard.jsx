import "./QuestionCard.css";

function QuestionCard({ question, onAnswer, selectedAnswer }) {
  return (
    <div className="card p-2" style={{ borderRadius: ".5rem 0rem 0rem .5rem" }}>
      <div className="card-body">
        <h5 className="mb-4">{question.question}</h5>

        <div className="d-flex flex-column gap-3">
          {question.options.map((option, index) => {
            const isSelected = selectedAnswer === option.text;
            const isCorrect = option.text === question.correctAnswer;

            let optionClass = "option-btn";

            if (selectedAnswer) {
              if (isCorrect) optionClass += " correct";
              else if (isSelected) optionClass += " wrong";
            } else if (isSelected) {
              optionClass += " selected";
            }

            return (
              <label key={index} className={optionClass}>
                <input
                  type="radio"
                  name={`question-${question.id}`}
                  value={option.text}
                  checked={isSelected}
                  disabled={selectedAnswer}
                  onChange={() => onAnswer(question, option)}
                />
                <span className="ms-2">{option.text}</span>
              </label>
            );
          })}
        </div>
      </div>
    </div>
  );
}

export default QuestionCard;
