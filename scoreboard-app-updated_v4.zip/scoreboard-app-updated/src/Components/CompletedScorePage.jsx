function CompletionPage() {
  return (
    <div className="container mt-5 text-center">
      <h2>Assessment Completed 🎉</h2>
      <p className="text-muted mt-3">
        Thank you for completing the assessment.
      </p>
    </div>
  );
}

export default CompletionPage;
