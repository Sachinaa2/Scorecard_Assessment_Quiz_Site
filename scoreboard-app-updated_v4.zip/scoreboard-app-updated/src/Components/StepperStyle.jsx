// StepperStyles.js
import Box from "@mui/material/Box";
import StepConnector from "@mui/material/StepConnector";
import { styled } from "@mui/material/styles";

/* 🔹 Shared Connector */
export const CustomConnector = styled(StepConnector)(() => ({
  "&.MuiStepConnector-alternativeLabel": {
    top: 8,
    left: "calc(-50% + clamp(10px, 2vw, 12px))",
    right: "calc(50% + clamp(10px, 2vw, 12px))",
  },

  "& .MuiStepConnector-line": {
    height: 2.5,
    border: 0,
    borderRadius: 2,
    backgroundColor: "#d6dde3",
  },

  "&.Mui-active .MuiStepConnector-line": {
    backgroundColor: "#1f5fa8",
  },

  "&.Mui-completed .MuiStepConnector-line": {
    backgroundColor: "#1f5fa8",
  },
}));

/* 🔹 Shared Step Icon */
export function CustomStepIcon({ active, completed, icon }) {
  return (
    <Box
      sx={{
        width: 20,
        height: 20,
        borderRadius: "50%",
        backgroundColor: active || completed ? "#1f5fa8" : "#d6dde3",
        color: "#fff",
        fontWeight: 700,
        fontSize: 12,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      {icon}
    </Box>
  );
}
