import Box from "@mui/material/Box";
import Stepper from "@mui/material/Stepper";
import Step from "@mui/material/Step";
import StepLabel from "@mui/material/StepLabel";
import { CustomConnector, CustomStepIcon } from "./StepperStyle";

export default function StepperBottom({ totalSteps, activeStep }) {
  return (
    <Box sx={{ width: "30%", margin: "auto", mt: 2 }}>
      <Stepper
        activeStep={activeStep}
        alternativeLabel
        connector={<CustomConnector />}
      >
        {Array.from({ length: totalSteps }).map((_, index) => (
          <Step key={index}>
            <StepLabel
              StepIconComponent={(props) =>
                CustomStepIcon({ ...props, icon: index + 1 })
              }
            />
          </Step>
        ))}
      </Stepper>
    </Box>
  );
}
