import "./ScoreDisplay.css";

function ScoreDisplay({
  totalScore,
  totalMaxScore,
  sectionScores,
  questionSections,
  activeSectionIndex,
}) {
  const totalPercentage = Math.round((totalScore / totalMaxScore) * 100);

  const dash = `${totalPercentage * 2.8} 290`;

  return (
    <div className="score-wrapper container-fluid my-5">
      <div className="row row-cols-2 row-cols-md-5 g-4">
        {/* 🔹 Overall Gauge */}
        <div className="col gauge-card text-center">
          <h4>Your Current Score</h4>

          <svg width="220" height="120">
            <path
              d="M20 100 A90 90 0 0 1 200 100"
              fill="none"
              stroke="#d6dde3"
              strokeWidth="14"
              strokeLinecap="round"
            />
            <path
              d="M20 100 A90 90 0 0 1 200 100"
              fill="none"
              stroke="#1f5fa8"
              strokeWidth="14"
              strokeLinecap="round"
              strokeDasharray={dash}
            />
          </svg>

          <div className="gauge-score">{totalPercentage}%</div>
        </div>

        {questionSections.map((section, index) => {
          const sectionMax = section.questions.reduce(
            (sum, q) => sum + Math.max(...q.options.map((o) => o.marks)),
            0,
          );

          let displayScore = 0;

          // 🟢 Completed sections → FULL
          if (index < activeSectionIndex) {
            displayScore = sectionMax;
          }

          // 🔵 Active section → ACTUAL SCORE
          if (index === activeSectionIndex) {
            displayScore = sectionScores[section.key];
          }

          // ⚪ Future sections → 0

          const percent = Math.round((displayScore / sectionMax) * 100);

          return (
            <div
              key={section.key}
              className="col linear-card align-self-center"
            >
              <h6>{section.key}</h6>

              <div className="progress">
                <div
                  className="progress-bar"
                  style={{
                    width: `${percent}%`,
                    transition: "width 0.4s ease",
                  }}
                />
              </div>

              <small>
                {displayScore} / {sectionMax}
              </small>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export default ScoreDisplay;
