import QuestionCard from "./QuestionCard";

function QuestionSlider({ question, onAnswer, answered, goNext, goPrev }) {
  return (
    <div className="container-fluid mt-4">
      <div className="row">
        {/* LEFT – Question (50%) */}
        <div className="col-md-6 p-0">
          <QuestionCard
            question={question}
            onAnswer={onAnswer}
            selectedAnswer={answered[question.id]}
          />
        </div>

        {/* RIGHT – Instruction Panel (50%) */}
        <div
          className="col-md-6 d-flex flex-column justify-content-between"
          style={{
            backgroundColor: "rgba(204, 222, 235, 0.5)",
            borderRadius: "0 .5rem .5rem 0",
          }}
        >
          <div className="p-4 h-100 d-flex flex-column justify-content-center">
            <h5>Instructions</h5>
            <p className="text-muted text-center mt-3">
              Select the option that best reflects your organization’s current
              state. You can navigate using Next and Previous.
            </p>
          </div>
        </div>
      </div>

      {/* Prev / Next Buttons */}
      <div className="row mt-3">
        <div className="col-12 d-flex align-items-center justify-content-between">
          <button
            className="col-md-5 btn"
            style={{ backgroundColor: "#ccdeeb80" }}
            onClick={goPrev}
          >
            Previous
          </button>

          <button
            className="col-md-5 btn"
            style={{ backgroundColor: "#ccdeeb80" }}
            onClick={goNext}
          >
            Next
          </button>
        </div>
      </div>
    </div>
  );
}

export default QuestionSlider;
