import Box from "@mui/material/Box";
import Stepper from "@mui/material/Stepper";
import Step from "@mui/material/Step";
import StepLabel from "@mui/material/StepLabel";
import Button from "@mui/material/Button";
import RefreshIcon from "@mui/icons-material/Refresh";
import { CustomConnector, CustomStepIcon } from "./StepperStyle";

/* 🔹 Steps */
const steps = [
  { label: "LINK", icon: "L" },
  { label: "ENGAGE", icon: "E" },
  { label: "ACTIVATE", icon: "A" },
  { label: "DRIVE", icon: "D" },
];

export default function StepperTop({ activeStep }) {
  return (
    <Box
      sx={{
        display: "flex",
        alignItems: "center",
        gap: 2,
        mb: 3,
        flexDirection: { xs: "column", md: "row" },
      }}
    >
      {/* LEFT SPACER */}
      <Box sx={{ width: "30%", display: { xs: "none", md: "block" } }} />

      {/* STEPPER */}
      <Box sx={{ width: { xs: "100%", md: "45%" } }}>
        <Stepper
          activeStep={activeStep}
          alternativeLabel
          connector={<CustomConnector />}
        >
          {steps.map((step, index) => (
            <Step key={step.label}>
              <StepLabel
                StepIconComponent={(props) =>
                  CustomStepIcon({ ...props, icon: step.icon })
                }
              >
                {step.label}
              </StepLabel>
            </Step>
          ))}
        </Stepper>
      </Box>

      {/* CLEAR BUTTON */}
      <Box sx={{ minWidth: 140 }}>
        <Button
          onClick={() => window.location.reload()}
          endIcon={<RefreshIcon />}
          sx={{
            minWidth: 140,
            height: 42,
            backgroundColor: "#fff",
            border: "2px solid #1f5fa8",
            color: "#1f5fa8",
            fontWeight: 600,
            textTransform: "none",
            borderRadius: "8px",
          }}
        >
          Clear
        </Button>
      </Box>
    </Box>
  );
}
